package dao;

import java.util.HashMap;

import java.util.Random;

import presentation.PaymentWallet;
import service.ExceptionClass;

public class PaymentWalletDaoImpl implements PaymentWalletDao {


	HashMap<String,PaymentWallet> list=new HashMap<>();
     PaymentWallet wallet=new PaymentWallet();
	@Override
	public String addAccount(PaymentWallet wallet) {
		// TODO Auto-generated method stub
		Random rand=new Random();
		int num=rand.nextInt(9000)+1000;
		String accountNo=String.valueOf(num);
		list.put(accountNo,wallet);
		System.out.println("Succesfully Created your Account Number is="+accountNo);
		return accountNo;
	}

	@Override
	public double addAmount(String accountNo, double amount)  {
		// TODO Auto-generated method stub
		try {	
			if(!list.containsKey(accountNo))
			{
				throw new Exception();
			}
				else{
					//System.out.println("Account 1 Found");
				wallet=list.get(accountNo);
				double temp;
				temp=wallet.getBalance();
				temp=temp+amount;
				wallet.setBalance(temp);
				//System.out.println("Successfully added the money to account");
			
			}
		}
catch(Exception e)
	      {
	           //System.out.println(e);
               
          }
		return amount;
	}

	@Override
	public PaymentWallet showBalance(String accountNo) {
		// TODO Auto-generated method stub
		if(list.containsKey(accountNo)) {
			
			wallet=list.get(accountNo);
		}
		return wallet;
	}

	@Override
	public void fundTransfer(String senderAc, String receiverAc, double amount) {
		// TODO Auto-generated method stub
		if(list.containsKey(senderAc))
		{
			System.out.println("Account 1 Found");
			PaymentWallet user1=list.get(senderAc);
			if(user1.getBalance()>=amount)
			{
				System.out.println("Sender Account  validated");
			}
			else
			{
				System.out.println("Requrired balance is not available");
			}
			try {
			if(!list.containsKey(receiverAc))
			{
				throw new Exception();
			}
			else {
				System.out.println("Account2 Found");
				PaymentWallet user2=list.get(receiverAc);
				double temp1=user1.getBalance();
				double temp2=user2.getBalance();
				temp1=temp1-amount;
				temp2=temp2+amount;
				user1.setBalance(temp1);
				user2.setBalance(temp2);
				System.out.println("Transaction Successful");
			}
			}
			catch(Exception e) {
				System.out.println(e);
				//throw e;
			}
		}			
	}		
	}
	

	
	

