package dao;

import presentation.PaymentWallet;


public interface PaymentWalletDao {
	public String addAccount(PaymentWallet wallet);
	public double addAmount(String accountNo,double amount);
	public PaymentWallet showBalance(String accountNo);
	public void fundTransfer(String senderAc,String receiverAc,double amount);
}
