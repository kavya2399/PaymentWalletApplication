package service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import presentation.PaymentWallet;

public class Validation {
	public boolean result=false;
	void validator(PaymentWallet wallet) throws ExceptionClass {
		validateName(wallet.getName());
		validatePhno(wallet.getPhNo());
	}
	public void  validateName(String name) throws ExceptionClass {
		Pattern p=Pattern.compile("[a-zA-Z]+");
		Matcher m=p.matcher(name);
		if(m.find()) {
			result=true;
		}
		else {
			throw new ExceptionClass("invalid name");
		}
		
	}
	public void validatePhno(long phno ) throws ExceptionClass {
		String s=String.valueOf(phno);
		Pattern p1=Pattern.compile("\\d{10}");
		Matcher m1=p1.matcher(s);
		if(!m1.find()) {
			throw new ExceptionClass("invalid phno");
		}
	}
}
