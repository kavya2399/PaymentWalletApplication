package service;

@SuppressWarnings("serial")
public class ExceptionClass extends Exception{
	public ExceptionClass(String msg) {
		System.out.println(msg);
	}

}
