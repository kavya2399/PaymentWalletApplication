package service;

import presentation.PaymentWallet;
import service.ExceptionClass;
public interface PaymentWalletService {
	
	
	public String addAccount(PaymentWallet wallet) throws ExceptionClass;
	public double addAmount(String accountNo,double amount) throws ExceptionClass;
	public PaymentWallet showBalance(String accountNo)throws ExceptionClass;
	public void fundTransfer(String SenderAc,String recieverAc,double amount);
	
}
