package service;


import dao.PaymentWalletDao;
import dao.PaymentWalletDaoImpl;
import presentation.PaymentWallet;
import service.ExceptionClass;

public class PaymentServiceImpl extends Validation implements PaymentWalletService{
PaymentWalletDao dao=new PaymentWalletDaoImpl();

@Override
public String addAccount(PaymentWallet wallet) throws ExceptionClass
 {
	// TODO Auto-generated method stub
	validator(wallet);
	return	dao.addAccount(wallet);
		
}

@Override
public double addAmount(String accountNo, double amount)throws ExceptionClass {
	// TODO Auto-generated method stub
	return dao.addAmount(accountNo, amount);
}

@Override
public PaymentWallet showBalance(String accountNo) {
	// TODO Auto-generated method stub
	return dao.showBalance(accountNo);
}

@Override
public void fundTransfer(String SenderAc, String recieverAc, double amount) {
	// TODO Auto-generated method stub
	dao.fundTransfer(SenderAc, recieverAc, amount);
}

	

}

