package ui;
import java.util.Scanner;

import presentation.PaymentWallet;
import service.ExceptionClass;
import service.PaymentServiceImpl;
import service.PaymentWalletService;

public class PaymentWalletStarter {
	static PaymentWalletService service=new PaymentServiceImpl();
	public static void showMenu() {
	System.out.println("1.Create Payment Wallet Account");
	System.out.println("2.Adding Amount");
	System.out.println("3.Show Amount");
	System.out.println("4.Fund Transfer");
	System.out.println("Enter your choice");
	
	}
	public static void main(String args[])throws ExceptionClass {
		
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		int choice;
		while(true) {
		showMenu();
		choice=sc.nextInt();
		switch(choice) {
		case 1:
			try { 
			System.out.println("Enter Your Name:");
			String name=sc.next();
			System.out.println("Enter Your Phone Number:");
		    long phno=sc.nextLong();
			System.out.println("Enter Your Password:");
			String password=sc.nextLine();
			sc.nextLine();
			PaymentWallet pw=new PaymentWallet();
			pw.setName(name);
			pw.setPhNo(phno);
			pw.setPassWord(password);
			pw.setBalance(0);
		    service.addAccount(pw);
			System.out.println("Added successfully");
			}catch(Exception e) {
				System.out.println(e.getMessage());
			}
			break;
		case 2:
			try {
			System.out.println("Enter Your Account Number");
			String accountNo=sc.next();
			System.out.println("Enter the amount:");
			double amount=sc.nextDouble();
			service.addAmount(accountNo, amount);
			}catch(Exception e) {
				System.out.println(e.getMessage());
			}
            break;
		case 3:
			System.out.println("Enter Your Account Number");
			String accountNo1=sc.next();
		    PaymentWallet user=service.showBalance(accountNo1);
		    System.out.println("Your Account Number is:"+accountNo1+"Your Current Balance is:"+user.getBalance());
		    break;
		case 4:
			System.out.println("Enter Your Account Number:");
			String senderAc=sc.next();
			System.out.println("Enter the receiver account number:");
			String receiverAc=sc.next();
			System.out.println("Enter the amount:");
			double fund=sc.nextDouble();
			service.fundTransfer(senderAc, receiverAc, fund);
			break;
		case 5:
			System.out.println("Thank You:)");
			System.exit(0);
            break;
		}
		}
			
	}
	
	}

		
